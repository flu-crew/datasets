#!/usr/bin/env bash

set -e
set -u

[ -z $BASH ] || shopt -s expand_aliases
alias BEGINCOMMENT="if [ ]; then"
alias ENDCOMMENT="fi"

##########################################################################################

function color-tips(){
        smot color leaf -Pp "(${1})" "#FF9000"
}

function color-branches(){
    smot color branch para --colormap colormap/colormap-${1} --factor-by-capture="USA\|([^|]*)"
}


# vaccine strains
vac_re="A02861318|A02751531|A02751457|A02861399|A02751535|A02751517|A02861299|A02685126"

# query (USA, 2022-present)
#octofludb query --fasta 000.rq | seqkit seq -w 0 -u > 000.fasta


# confirm vaccine strains in 000.fasta


for segment in H1 H3
do
	# split into H1/H3
	smof grep "|${segment}|" 000.fasta > ${segment}.fasta
	# remove duplicates
	seqkit rmdup --id-regexp "^[^\\|]*\\|([^\\|]*)" -i ${segment}.fasta |
		seqkit seq -w 0 -u > ${segment}.fasta~
	mv ${segment}.fasta~ ${segment}.fasta
	# crop HA1
	smof translate -s -f ${segment}.fasta |
		flutile trim ha1 --subtype ${segment} --conversion aa2aa |
		seqkit seq -w 0 -u > ${segment}-HA1.fasta
	# align
	mafft ${segment}.fasta | seqkit seq -w 0 -u > ${segment}.fna
	rm ${segment}.fasta
	mafft ${segment}-HA1.fasta | seqkit seq -w 0 -u > ${segment}-HA1.faa
	rm ${segment}-HA1.fasta
done


# Manually inspect alignment files before continuing. Confirm absence of large gaps in 
# alignment and appropriate cropping in HA1.


for segment in H1 H3
do
	FastTree -nt -gtr -gamma ${segment}.fna > ${segment}.fna.tre
	# use parnas to build AA HA1 rescaled tree
	parnas -t ${segment}.fna.tre --aa ${segment}-HA1.faa --threshold 95 --cover > /dev/null
	mv treetime_ancestral_${segment}.fna.tre/ancestral_reweighed.tre ${segment}.HA1.aa.rescaled.tre
	rm -rf treetime_ancestral_${segment}.fna.tre
	# find clusters to calculate total coverage of original selections
	parnas -t ${segment}.HA1.aa.rescaled.tre --exclude-rep '^((?!A02861318|A02751531|A02751457|A02861399|A02751535|A02751517|A02861299|A02685126).)*$' --cover --radius 16 --clusters ${segment}-HA1-cluster.txt
done


# color trees
for segment in H1 H3
do
	smot color rm ${segment}.HA1.aa.rescaled.tre |
		color-tips "${vac_re}" |
		color-branches "${segment}" > ${segment}-color.HA1.aa.rescaled.tre
done
